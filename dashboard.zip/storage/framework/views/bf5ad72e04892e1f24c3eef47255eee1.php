<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Indramayu Open Data Dashboard'); ?></title>
    <meta name="description"
        content="<?php echo $__env->yieldContent('description', 'Visualize and explore open data from the Government of Indramayu Regency.'); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-slate-50 font-sans antialiased text-slate-800">
    <div class="min-h-screen flex flex-col">
        <!-- Header -->
        <header class="bg-gradient-to-r from-blue-700 to-indigo-800 shadow-md sticky top-0 z-50">
            <div
                class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 md:py-0 md:h-16 flex flex-col md:flex-row items-center justify-between gap-4 md:gap-0">
                <div class="flex items-center gap-3">
                    <div
                        class="w-8 h-8 rounded bg-white/20 backdrop-blur-sm flex items-center justify-center text-white font-bold border border-white/30">
                        I
                    </div>
                    <h1 class="text-xl font-bold text-white tracking-tight">Indramayu <span class="text-blue-200">Open
                            Data</span></h1>
                </div>
                <nav
                    class="flex gap-4 md:gap-6 w-full md:w-auto justify-center md:justify-end overflow-x-auto pb-1 md:pb-0">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="text-sm font-medium whitespace-nowrap <?php echo e(request()->routeIs('dashboard') ? 'text-white' : 'text-blue-200 hover:text-white'); ?> transition">Dashboard</a>
                    <a href="<?php echo e(route('datasets.index')); ?>"
                        class="text-sm font-medium whitespace-nowrap <?php echo e(request()->routeIs('datasets.*') ? 'text-white' : 'text-blue-200 hover:text-white'); ?> transition">Datasets</a>
                    <a href="<?php echo e(route('organizations.index')); ?>"
                        class="text-sm font-medium whitespace-nowrap <?php echo e(request()->routeIs('organizations.*') ? 'text-white' : 'text-blue-200 hover:text-white'); ?> transition">Organizations</a>
                </nav>
            </div>
        </header>

        <!-- Main Content -->
        <main class="flex-grow">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <!-- Footer -->
        <footer class="bg-white border-t border-slate-200 py-6 mt-auto">
            <div class="max-w-7xl mx-auto px-4 text-center text-slate-500 text-sm">
                &copy; <?php echo e(date('Y')); ?> Pemerintah Kabupaten Indramayu. All rights reserved.
            </div>
        </footer>
    </div>

    <!-- Chart.js Library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>

</html><?php /**PATH /Applications/MAMP/htdocs/BI2/resources/views/layouts/app.blade.php ENDPATH**/ ?>